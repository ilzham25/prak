a = True
b = False
c = True

d = a and c
print(d)

d = a and b
print(d)

d = a or b
print(d)

d = a or c
print(c)
