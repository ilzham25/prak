kata = "hari ini belajar python"

print("hari" in kata)
print("malam" in kata)
print("belajar" not in kata)
print("piton" not in kata)

print(" ")

kata = 5, 8, "Sistem"

print(5 in kata)
print(8 in kata)
print(8 not in kata)
print("Sistem" not in kata)