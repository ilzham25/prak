namahari = ['Senin','Selasa','Rabu','Kamis']
print(namahari)