angka1 = 2
a = angka1 + 4 + \
    7 + \
    5

print(a)