kutip1 = 'BELAJAR PYTHON'
kutip2 = "BELAJAR PYTHON DASAR"
kutip3 = """BELAJAR PYTHON SETIAP HARI ADALAH JALAN NINJA KU"""

print(kutip1)
print(kutip2)
print(kutip3)