print("BARIS")
print("INDENTASI")