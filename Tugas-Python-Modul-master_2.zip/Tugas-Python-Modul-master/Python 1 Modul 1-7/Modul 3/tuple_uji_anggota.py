tuple1 = (1,2,3, 'a','b','c')

#menggunakan in
#output: True
print(3 in tuple1)

#output: False
print('2' in tuple1)

#output: False
print('e' in tuple1)

#menggunakan not in
#output: True
print('k' not in tuple1)
