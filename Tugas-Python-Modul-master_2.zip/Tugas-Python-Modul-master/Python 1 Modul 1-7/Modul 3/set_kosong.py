# membuat variabel a dengan {}
a = {}
print(type(a))
#output <class 'dict'>

#harus menggunakan fungsi set()
a = set()
print(type(a))
#output <class 'set'>