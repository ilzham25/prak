#membuat set baru
#output: set berisi anggota yang unik
set_saya = set("HelloPython")
print(set_saya)

#pop anggota
#output: anggota acak
print(set_saya.pop())
print(set_saya)

#pop anggota lainnya
#output: anggota acak
print(set_saya.pop())
print(set_saya)

#mengosongkan set
#output: set()
set_saya.clear()
print(set_saya)