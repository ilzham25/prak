tuple1 = ['p','y','t','h','o','n']
#output: 'p'
print(tuple1[0])

#output: 'y'
print(tuple1[1])

#output: 'n'
print(tuple1[-1])

#output 'o'
print(tuple1[-2])

#index Error
#print(tuple[6])