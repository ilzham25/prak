tuple1 = ('p','y','t','h','o','n','s','a','y','a')
# count
#output: 2
print(tuple1.count('a'))

#indeks
#output 4
print(tuple1.index('n'))