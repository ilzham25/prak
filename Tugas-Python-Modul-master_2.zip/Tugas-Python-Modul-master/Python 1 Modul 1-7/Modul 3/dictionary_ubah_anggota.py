dict_saya = {'nama':'Ikhsan', 'usia':35}

#mengupdate nilai
dict_saya['usia'] = 36
#output: {'nama': 'Ikhsan', 'usia':36}
print(dict_saya)

#menambah anggota
dict_saya['alamat'] = 'Tanjungpinang'
#output: {'alamat: 'Tanjungpinang', 'nama':'Ikhsan', 'usia':36}
print(dict_saya)