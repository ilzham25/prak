tuple1 = ('p','r','o','g','r','a','m','m','i','n','g')
#akses dari indeks 0 s/d 2

#output: ('p','r','o')
print(tuple1[:3])

#akses dari indeks 2 s/d 5
#output: ('o','g','r','a')
print(tuple1[2:6])

#akses dari indeks 3 sampai akhir
#output: ('g,'r','a','m','m','i','n','g')
print(tuple1[3:])
