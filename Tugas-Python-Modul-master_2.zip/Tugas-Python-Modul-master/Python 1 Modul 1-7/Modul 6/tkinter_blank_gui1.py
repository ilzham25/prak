import tkinter

root = tkinter.Tk()

root.mainloop()