def persegipanjang(panjang,lebar):
    luas = panjang * lebar
    print("luasnya :", luas)
    return luas

print("menghitung luas persegi panjang")
a = int(input("Masukan Panjang : "))
b = int(input("Masukan Lebar :"))
persegipanjang(a,b)
