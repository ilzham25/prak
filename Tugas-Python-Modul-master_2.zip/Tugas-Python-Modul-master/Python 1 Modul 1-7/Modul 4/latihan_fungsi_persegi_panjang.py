def persegipanjang(panjang,lebar):
    luas = panjang * lebar
    print("Luasnya :",luas)
    return luas

print("Menghitung Luas persegi panjang")
persegipanjang(4,6)