bilangan =5.5

if bilangan >0:
    print("Bilangan positif")
elif bilangan == 0:
    print("Nol")
else:
    print("bilangan negatif")