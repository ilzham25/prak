hitung = 0

while (hitung < 10):
    print("Hitung :",hitung)
    hitung = hitung +1