bilangan = 1

if bilangan >= 0:
    print("positif atau Nol")
else:
    print("bilangan negatif")