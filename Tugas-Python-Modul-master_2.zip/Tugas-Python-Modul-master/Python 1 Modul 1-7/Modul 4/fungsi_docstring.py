def sapa(nama):
    "contoh cetak keterangan"
    print("Hai," + nama + ". Apa kabar?")
    return nama

sapa("Adhit")
print(sapa.__doc__)