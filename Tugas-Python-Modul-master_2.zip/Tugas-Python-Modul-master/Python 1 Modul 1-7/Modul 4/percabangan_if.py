angka = 4
if angka > 0:
    print(angka, "adalah Bilangan positif.")