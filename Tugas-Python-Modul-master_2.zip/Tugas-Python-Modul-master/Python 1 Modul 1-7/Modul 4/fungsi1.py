def sapa(nama):
    print("Hai, " + nama + ". Apa Kabar?")
    return nama

#pemanggilan fungsi
#output : Hai, Adhit. Apa Kabar?
sapa("Adhit")