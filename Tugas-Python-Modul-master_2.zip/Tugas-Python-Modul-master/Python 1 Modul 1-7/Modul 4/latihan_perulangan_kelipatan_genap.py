i = 0
n = int(input("Masukan Batas : "))

for i in range(n):
    if i%2 == 0:
        print("Bilangan :",i)

    i = i + 1