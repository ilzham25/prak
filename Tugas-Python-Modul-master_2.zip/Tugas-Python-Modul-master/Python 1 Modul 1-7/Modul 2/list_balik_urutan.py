alfabet = ['a','c','d','e','b']
alfabet.reverse()
print(alfabet)
#output kebalikan dari alfabet di atas