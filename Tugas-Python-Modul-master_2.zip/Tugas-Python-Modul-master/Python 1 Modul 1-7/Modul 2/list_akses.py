my_list = ["Saya", "belajar", "python", "programming", 2019]
#output : Saya
print(my_list[0])

#output :python
print(my_list[2])

#list dalam list
your_list = ['hello', [1,2,3], 'python']

#output 1
print(your_list[1][0])

#output 3
print(your_list[1][2])

#output hello
print(your_list[0])

#index Error
#print(my_list[6])