alfabet = ['a','b','d','f','e','c','h','g','j','i']
alfabet.sort()
print(alfabet)
#output ['a','b','c','d','e','f','g','h','i','j']

alfabet.sort(reverse=True)
print(alfabet)
#output kebalikan dari alfabet di atas