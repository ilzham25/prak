my_list = ['p','y','t','h','o','n','s','a','y','a']

# anggota list dari 3 s/d 5 (dari h s/d n)
print(my_list[3:6])

# anggota list dari 4 s/d yang terakhir
print(my_list[4:])

# anggota list dari 0 s/d 4
print(my_list[:5])