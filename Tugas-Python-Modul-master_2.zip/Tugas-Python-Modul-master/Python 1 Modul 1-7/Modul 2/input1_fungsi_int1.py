a = int(input("Masukan Nilai A : "))
b = int(input("Masukan Nilai B : "))

c = a + b
print(c)