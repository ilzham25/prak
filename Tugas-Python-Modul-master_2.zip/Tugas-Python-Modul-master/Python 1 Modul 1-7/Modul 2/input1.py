a = input("Masukan Nilai A : ")
b = input("Masukan Nilai B : ")

print(a,b)