import math

c = math.sqrt(36)
print(c)