c = pow(2,3)
print(c)