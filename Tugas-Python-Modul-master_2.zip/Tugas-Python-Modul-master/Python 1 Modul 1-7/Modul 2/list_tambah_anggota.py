ganjil = [1,3,5,7]

ganjil.append(9)
print(ganjil)
[1,3,5,7,9]

ganjil.extend([11,13,15])
print(ganjil)
[1,3,5,7,9,11,13,15]