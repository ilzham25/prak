ganjil = [5,7,11,13,15]

#menyisipkan 9 setelah angka 7
ganjil.insert(2,9)
print(ganjil)
