import math

print(max(2,1,5)) #output-nya 5

print(min(2,1,5)) #output-nya 1

print(round(5.8)) #output-nya 6

print(math.floor(5.8)) #output-nya 5

print(math.ceil(5.8)) #output-nya 6