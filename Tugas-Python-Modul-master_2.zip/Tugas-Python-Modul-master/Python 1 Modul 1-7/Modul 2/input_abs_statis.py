a = -5

c = abs(a)
print(c)
