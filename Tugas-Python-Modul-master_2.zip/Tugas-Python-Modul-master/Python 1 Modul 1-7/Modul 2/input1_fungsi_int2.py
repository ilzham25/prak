a = input("Masukan Nilai A : ")
b = input("Masukan Nilai B : ")

c = int(a) + int(b)
print(c)