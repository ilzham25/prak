a = int(input("Masukan Nilai A : "))

c = abs(a)
print(c)