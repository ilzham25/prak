import math

a = input("Masukan Nilai : ")

c = math.sqrt(int(a))
print(c)