a = int(input("Masukan Nilai : "))
b = int(input("Masukan Nilai Pangkat : "))

c = pow(a,b)
print(c)