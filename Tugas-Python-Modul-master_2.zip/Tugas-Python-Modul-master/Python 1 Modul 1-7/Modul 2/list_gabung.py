genap = [2, 4, 6]
print(genap + [8, 10, 12])
# output [2, 4, 6, 8, 10, 12]

print(['p','y'] * 2)
# output ['p','y','p','y']