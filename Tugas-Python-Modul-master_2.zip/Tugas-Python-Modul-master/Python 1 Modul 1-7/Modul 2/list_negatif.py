my_list = ['p','y','t','h','o','n']

# output: n
print(my_list[-1])

# output: h
print(my_list[-3])