string1 = "Hello world"

print(len(string1))