kata = "HelloWorld"

print(kata[3:6])
print(kata[7:])
